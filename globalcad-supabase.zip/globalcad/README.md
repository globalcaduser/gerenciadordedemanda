# GlobalCad — Gestão de Tarefas

Sistema Kanban com autenticação, alertas por e-mail (Gmail), SLA, histórico de alterações e gestão de usuários — powered by **Supabase**.

---

## 🚀 Início Rápido

### 1. Configurar o Supabase

1. Crie um projeto em [supabase.com](https://supabase.com)
2. No **SQL Editor** (Dashboard → SQL Editor), cole e execute o conteúdo de:
   ```
   supabase/migrations/001_initial.sql
   ```
3. Anote os valores em **Settings → API**:
   - `Project URL`
   - `anon public key`

### 2. Configurar o código

Abra `src/index.html` e substitua nas linhas indicadas:

```js
const SUPABASE_URL      = "https://SEU_PROJECT.supabase.co";  // ← sua URL
const SUPABASE_ANON_KEY = "SEU_ANON_KEY";                      // ← sua chave
```

### 3. Abrir no navegador

Basta abrir `src/index.html` diretamente no navegador — não precisa de servidor.

Para produção, hospede em qualquer CDN estático:
- **Vercel**: `vercel deploy`
- **Netlify**: arraste a pasta `src/`
- **GitHub Pages**: habilite nas configurações do repositório

---

## 📁 Estrutura do Projeto

```
globalcad/
├── src/
│   └── index.html                    ← Aplicação completa (React via CDN)
├── supabase/
│   ├── migrations/
│   │   └── 001_initial.sql           ← Schema completo do banco
│   ├── functions/
│   │   └── send-email/
│   │       └── index.ts              ← Edge Function: envio via Gmail
│   └── config.toml                   ← Configuração do Supabase CLI
└── README.md
```

---

## ✉️ Integração Gmail (Alertas de Status)

Sempre que uma tarefa muda de status, um trigger no banco enfileira um e-mail para o responsável. A Edge Function `send-email` processa essa fila.

### Configurar Gmail OAuth2

1. Acesse [console.cloud.google.com](https://console.cloud.google.com)
2. Crie ou selecione um projeto → ative a **Gmail API**
3. Crie credenciais **OAuth 2.0** (tipo: "Aplicativo da Web")
4. Adicione como URI de redirecionamento:
   ```
   https://developers.google.com/oauthplayground
   ```
5. Acesse o [OAuth Playground](https://developers.google.com/oauthplayground):
   - Em "OAuth 2.0 Configuration" (⚙️), marque **"Use your own OAuth credentials"**
   - Cole Client ID e Client Secret
   - Selecione o escopo: `https://mail.google.com/`
   - Clique em **"Authorize APIs"** → **"Exchange authorization code for tokens"**
   - Copie o `refresh_token`

### Deploy da Edge Function

```bash
# Instale o Supabase CLI
npm install -g supabase

# Login
supabase login

# Vincule ao seu projeto
supabase link --project-ref SEU_PROJECT_REF

# Configure as variáveis de ambiente
supabase secrets set GMAIL_CLIENT_ID=seu_client_id
supabase secrets set GMAIL_CLIENT_SECRET=seu_client_secret
supabase secrets set GMAIL_REFRESH_TOKEN=seu_refresh_token
supabase secrets set GMAIL_FROM=noreply@seudominio.com.br

# Deploy
supabase functions deploy send-email
```

### Agendar envio automático (pg_cron)

No SQL Editor do Supabase, execute:

```sql
-- Habilitar extensão (só precisa fazer uma vez)
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Disparar a edge function a cada 5 minutos
SELECT cron.schedule(
  'send-pending-emails',
  '*/5 * * * *',
  $$
  SELECT net.http_post(
    url    := 'https://SEU_PROJECT.supabase.co/functions/v1/send-email',
    headers := jsonb_build_object(
      'Authorization', 'Bearer ' || current_setting('app.anon_key'),
      'Content-Type', 'application/json'
    )
  )
  $$
);
```

---

## 👥 Gestão de Usuários

| Papel       | Pode fazer |
|-------------|------------|
| 👤 Membro   | Ver e editar tarefas |
| 👔 Gerente  | + Gerenciar clientes, tipos de tarefa; deletar tarefas |
| 🔑 Admin    | + Alterar papéis, convidar usuários |

Para criar o primeiro usuário administrador:

1. No Dashboard do Supabase → **Authentication → Users → Add user**
2. Após o cadastro, no SQL Editor:
   ```sql
   UPDATE profiles
   SET role = 'admin'
   WHERE email = 'admin@seudominio.com';
   ```

---

## 🏗️ Funcionalidades

- **Kanban** com drag & drop entre colunas
- **Visão em grade** (tabela)
- **SLA configurável** por prioridade com alertas visuais
- **Histórico** de alterações por tarefa
- **Alertas por e-mail** automáticos via Gmail ao mudar status
- **Filtros** por cliente, prioridade, responsável, SLA e busca de texto
- **Tema** claro/escuro (persistido)
- **Autenticação** completa (login/logout)
- **Multi-usuário** com atualização em tempo real (polling; use SDK para WebSocket)

---

## 🔧 Tecnologias

| Camada | Tecnologia |
|--------|-----------|
| Frontend | React 18 (via CDN, sem build step) |
| Backend / DB | Supabase (PostgreSQL) |
| Auth | Supabase Auth |
| Alertas | Gmail API (OAuth2) via Edge Function (Deno) |
| Hospedagem | Qualquer CDN estático |

---

## 📝 Notas de Migração (versão anterior)

Se você estava usando a versão com `localStorage`, os dados **não são migrados automaticamente**. Para migrar:

1. Abra a versão antiga no navegador
2. No console do DevTools, execute:
   ```js
   copy(JSON.stringify(JSON.parse(localStorage.getItem("geo-tasks"))))
   ```
3. Use o SQL Editor do Supabase ou um script de importação para inserir os dados

---

## 🤝 Suporte

Em caso de dúvidas sobre configuração do Supabase, consulte a [documentação oficial](https://supabase.com/docs).
