// supabase/functions/send-email/index.ts
// Edge Function: processa a fila de e-mails pendentes via Gmail API (OAuth2)
//
// Variáveis de ambiente necessárias (Supabase Dashboard → Settings → Edge Functions):
//   GMAIL_CLIENT_ID      — OAuth2 Client ID do Google Cloud Console
//   GMAIL_CLIENT_SECRET  — OAuth2 Client Secret
//   GMAIL_REFRESH_TOKEN  — Refresh Token (gerado via OAuth Playground)
//   GMAIL_FROM           — E-mail remetente (ex: noreply@globalcad.com.br)

import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

/** Obtém um access_token usando o refresh_token do Gmail OAuth2 */
async function getGmailAccessToken(): Promise<string> {
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id:     Deno.env.get("GMAIL_CLIENT_ID")!,
      client_secret: Deno.env.get("GMAIL_CLIENT_SECRET")!,
      refresh_token: Deno.env.get("GMAIL_REFRESH_TOKEN")!,
      grant_type:    "refresh_token",
    }),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Falha ao obter access_token: ${err}`);
  }

  const { access_token } = await res.json();
  return access_token;
}

/** Envia um e-mail via Gmail API */
async function sendEmail(
  accessToken: string,
  to: string,
  toName: string | null,
  subject: string,
  htmlBody: string
): Promise<{ ok: boolean; error?: string }> {
  const fromEmail = Deno.env.get("GMAIL_FROM") || "noreply@globalcad.com.br";
  const toHeader  = toName ? `"${toName}" <${to}>` : to;

  // Monta mensagem no formato RFC 2822
  const message = [
    `From: GlobalCad <${fromEmail}>`,
    `To: ${toHeader}`,
    `Subject: =?UTF-8?B?${btoa(unescape(encodeURIComponent(subject)))}?=`,
    `MIME-Version: 1.0`,
    `Content-Type: text/html; charset=UTF-8`,
    `Content-Transfer-Encoding: base64`,
    ``,
    btoa(unescape(encodeURIComponent(htmlBody))),
  ].join("\r\n");

  // Codifica em Base64 URL-safe
  const raw = btoa(message)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");

  const res = await fetch(
    "https://gmail.googleapis.com/gmail/v1/users/me/messages/send",
    {
      method:  "POST",
      headers: {
        Authorization:  `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ raw }),
    }
  );

  if (!res.ok) {
    const errBody = await res.text();
    return { ok: false, error: errBody };
  }

  return { ok: true };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Busca até 20 notificações pendentes
    const { data: pending, error: fetchError } = await supabase
      .from("email_notifications")
      .select("*")
      .eq("sent", false)
      .is("error", null)           // não retenta erros automaticamente
      .order("created_at", { ascending: true })
      .limit(20);

    if (fetchError) throw fetchError;

    if (!pending || pending.length === 0) {
      return new Response(
        JSON.stringify({ message: "Nenhum e-mail pendente", sent: 0 }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Obtém token uma única vez para todo o lote
    const accessToken = await getGmailAccessToken();

    let sent = 0;
    const errors: string[] = [];

    for (const notif of pending) {
      const result = await sendEmail(
        accessToken,
        notif.to_email,
        notif.to_name,
        notif.subject,
        notif.body_html
      );

      await supabase
        .from("email_notifications")
        .update({
          sent:    result.ok,
          sent_at: result.ok ? new Date().toISOString() : null,
          error:   result.ok ? null : result.error,
        })
        .eq("id", notif.id);

      if (result.ok) {
        sent++;
      } else {
        errors.push(`${notif.to_email}: ${result.error}`);
      }
    }

    return new Response(
      JSON.stringify({ sent, errors, total: pending.length }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (err) {
    console.error("send-email error:", err);
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
