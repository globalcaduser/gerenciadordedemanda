-- =============================================
-- GlobalCad — Schema Inicial
-- Execute no SQL Editor do Supabase Dashboard
-- =============================================

-- =============================================
-- TABELA: profiles (extensão de auth.users)
-- =============================================
CREATE TABLE IF NOT EXISTS profiles (
  id          UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name        TEXT NOT NULL DEFAULT '',
  initials    TEXT NOT NULL DEFAULT '??',
  color       TEXT NOT NULL DEFAULT '#0984E3',
  role        TEXT NOT NULL DEFAULT 'member'
                CHECK (role IN ('admin', 'manager', 'member')),
  email       TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABELA: clients
-- =============================================
CREATE TABLE IF NOT EXISTS clients (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  color      TEXT NOT NULL DEFAULT '#0984E3',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO clients (id, name, color) VALUES
  ('delta', 'DELTA', '#0984E3'),
  ('enep', 'ENEP', '#00B894'),
  ('engedata', 'ENGEDATA', '#E17055'),
  ('florecer', 'FLORECER', '#6C5CE7'),
  ('jm_construcoes', 'JM CONSTRUÇÕES', '#D63031'),
  ('quatro_construcoes', 'QUATRO CONSTRUÇÕES', '#FDCB6E')
ON CONFLICT (id) DO NOTHING;

-- =============================================
-- TABELA: task_types
-- =============================================
CREATE TABLE IF NOT EXISTS task_types (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  icon       TEXT NOT NULL DEFAULT '📋',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO task_types (id, name, icon) VALUES
  ('reuniao',   'Reunião Implantação',      '🤝'),
  ('execucao',  'Execução Implantação',     '⚙️'),
  ('liberacao', 'Liberação para Operação',  '🚀')
ON CONFLICT (id) DO NOTHING;

-- =============================================
-- TABELA: tasks
-- =============================================
CREATE TABLE IF NOT EXISTS tasks (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title        TEXT NOT NULL,
  description  TEXT DEFAULT '',
  column       TEXT NOT NULL DEFAULT 'pendente'
                 CHECK (column IN ('pendente', 'andamento', 'concluido')),
  client_id    TEXT REFERENCES clients(id),
  priority     TEXT NOT NULL DEFAULT 'media'
                 CHECK (priority IN ('baixa', 'media', 'importante', 'urgente')),
  assignee_id  UUID REFERENCES profiles(id),
  requester_id UUID REFERENCES profiles(id),
  task_type    TEXT REFERENCES task_types(id),
  deadline     DATE,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABELA: task_attachments
-- =============================================
CREATE TABLE IF NOT EXISTS task_attachments (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id    UUID REFERENCES tasks(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,
  size       BIGINT,
  mime_type  TEXT,
  url        TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABELA: task_history (auditoria)
-- =============================================
CREATE TABLE IF NOT EXISTS task_history (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id    UUID REFERENCES tasks(id) ON DELETE CASCADE,
  user_id    UUID REFERENCES profiles(id),
  field      TEXT NOT NULL,
  old_value  TEXT,
  new_value  TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABELA: sla_config
-- =============================================
CREATE TABLE IF NOT EXISTS sla_config (
  priority TEXT PRIMARY KEY,
  days     INT NOT NULL
);

INSERT INTO sla_config (priority, days) VALUES
  ('baixa', 30), ('media', 10), ('importante', 5), ('urgente', 2)
ON CONFLICT (priority) DO NOTHING;

-- =============================================
-- TABELA: email_notifications
-- =============================================
CREATE TABLE IF NOT EXISTS email_notifications (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id    UUID REFERENCES tasks(id) ON DELETE CASCADE,
  to_email   TEXT NOT NULL,
  to_name    TEXT,
  subject    TEXT NOT NULL,
  body_html  TEXT NOT NULL,
  sent       BOOLEAN DEFAULT FALSE,
  sent_at    TIMESTAMPTZ,
  error      TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- FUNÇÃO: updated_at automático
-- =============================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tasks_updated_at ON tasks;
CREATE TRIGGER tasks_updated_at
  BEFORE UPDATE ON tasks
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS profiles_updated_at ON profiles;
CREATE TRIGGER profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- =============================================
-- FUNÇÃO: cria profile ao registrar usuário
-- =============================================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, name, email, initials, color)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    NEW.email,
    UPPER(LEFT(COALESCE(NEW.raw_user_meta_data->>'name', NEW.email), 1) ||
          COALESCE(LEFT(split_part(COALESCE(NEW.raw_user_meta_data->>'name', ''), ' ', 2), 1), '')),
    '#0984E3'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- =============================================
-- FUNÇÃO + TRIGGER: histórico e notificações
-- =============================================
CREATE OR REPLACE FUNCTION log_task_changes()
RETURNS TRIGGER AS $$
DECLARE
  col_labels JSONB := '{"pendente":"Fila","andamento":"Em Andamento","concluido":"Concluídas"}'::JSONB;
  pri_labels JSONB := '{"baixa":"Baixa","media":"Média","importante":"Importante","urgente":"Urgente"}'::JSONB;
  assignee_name TEXT;
  assignee_email TEXT;
  task_url TEXT := 'https://sua-url.com/tasks/';
BEGIN
  -- Log: mudança de status (coluna)
  IF OLD.column IS DISTINCT FROM NEW.column THEN
    INSERT INTO task_history(task_id, field, old_value, new_value)
    VALUES (NEW.id, 'column',
      col_labels->>OLD.column, col_labels->>NEW.column);

    -- Notificação por e-mail ao responsável
    SELECT p.name, p.email INTO assignee_name, assignee_email
    FROM profiles p WHERE p.id = NEW.assignee_id AND p.email IS NOT NULL;

    IF assignee_email IS NOT NULL THEN
      INSERT INTO email_notifications(task_id, to_email, to_name, subject, body_html)
      VALUES (
        NEW.id,
        assignee_email,
        assignee_name,
        '📋 GlobalCad — "' || NEW.title || '" mudou de status',
        '<div style="font-family:''DM Sans'',sans-serif;max-width:560px;margin:0 auto;background:#F3F4F6;padding:32px 16px">' ||
        '<div style="background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08)">' ||
        '<div style="background:#0F1117;padding:20px 28px;display:flex;align-items:center;gap:12">' ||
        '<span style="color:#fff;font-size:20px;font-weight:800">GlobalCad</span>' ||
        '<span style="color:#6B7280;font-size:11px;margin-left:8px;border-left:1px solid #2A2D3A;padding-left:12px">Gestão de Tarefas</span>' ||
        '</div>' ||
        '<div style="padding:28px">' ||
        '<p style="color:#6B7280;font-size:13px;margin:0 0 4px">Olá, ' || COALESCE(assignee_name, 'usuário') || '</p>' ||
        '<h2 style="color:#111827;font-size:18px;font-weight:800;margin:0 0 20px">Atualização de tarefa</h2>' ||
        '<div style="background:#F9FAFB;border-radius:8px;padding:16px;border-left:4px solid #0984E3;margin-bottom:20px">' ||
        '<p style="color:#111827;font-weight:700;font-size:15px;margin:0 0 8px">' || NEW.title || '</p>' ||
        '<p style="color:#6B7280;font-size:13px;margin:0">Status alterado:</p>' ||
        '<p style="font-size:14px;margin:6px 0 0">' ||
        '<span style="color:#6B7280">' || COALESCE(col_labels->>OLD.column, OLD.column) || '</span>' ||
        '<span style="color:#9CA3AF;margin:0 8px">→</span>' ||
        '<span style="color:#0984E3;font-weight:700">' || COALESCE(col_labels->>NEW.column, NEW.column) || '</span>' ||
        '</p></div>' ||
        '<a href="' || task_url || NEW.id || '" style="display:inline-block;background:#0984E3;color:#fff;padding:10px 22px;border-radius:8px;text-decoration:none;font-weight:700;font-size:13px">Ver tarefa →</a>' ||
        '</div></div>' ||
        '<p style="color:#9CA3AF;font-size:11px;text-align:center;margin-top:16px">GlobalCad · Sistema de Gestão de Tarefas</p>' ||
        '</div>'
      );
    END IF;
  END IF;

  -- Log: mudança de prioridade
  IF OLD.priority IS DISTINCT FROM NEW.priority THEN
    INSERT INTO task_history(task_id, field, old_value, new_value)
    VALUES (NEW.id, 'priority',
      pri_labels->>OLD.priority, pri_labels->>NEW.priority);
  END IF;

  -- Log: mudança de responsável
  IF OLD.assignee_id IS DISTINCT FROM NEW.assignee_id THEN
    INSERT INTO task_history(task_id, field, old_value, new_value)
    VALUES (NEW.id, 'assignee_id', OLD.assignee_id::TEXT, NEW.assignee_id::TEXT);
  END IF;

  -- Log: mudança de prazo
  IF OLD.deadline IS DISTINCT FROM NEW.deadline THEN
    INSERT INTO task_history(task_id, field, old_value, new_value)
    VALUES (NEW.id, 'deadline', OLD.deadline::TEXT, NEW.deadline::TEXT);
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS task_changes_trigger ON tasks;
CREATE TRIGGER task_changes_trigger
  AFTER UPDATE ON tasks
  FOR EACH ROW EXECUTE FUNCTION log_task_changes();

-- =============================================
-- ROW LEVEL SECURITY
-- =============================================
ALTER TABLE profiles         ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks            ENABLE ROW LEVEL SECURITY;
ALTER TABLE clients          ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_types       ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_history     ENABLE ROW LEVEL SECURITY;
ALTER TABLE sla_config       ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_notifications ENABLE ROW LEVEL SECURITY;

-- Profiles
CREATE POLICY "profiles_select" ON profiles FOR SELECT
  USING (auth.role() = 'authenticated');
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
  USING (id = auth.uid());

-- Tasks: todos autenticados leem e criam; só admin deleta
CREATE POLICY "tasks_select"  ON tasks FOR SELECT  USING (auth.role() = 'authenticated');
CREATE POLICY "tasks_insert"  ON tasks FOR INSERT  WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "tasks_update"  ON tasks FOR UPDATE  USING (auth.role() = 'authenticated');
CREATE POLICY "tasks_delete"  ON tasks FOR DELETE
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','manager')));

-- Clients e task_types: todos leem, admins gerenciam
CREATE POLICY "clients_select" ON clients FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "clients_all"    ON clients FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','manager')));

CREATE POLICY "task_types_select" ON task_types FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "task_types_all"    ON task_types FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','manager')));

-- Attachments: todos autenticados
CREATE POLICY "attachments_select" ON task_attachments FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "attachments_insert" ON task_attachments FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "attachments_delete" ON task_attachments FOR DELETE USING (auth.role() = 'authenticated');

-- History: apenas leitura para autenticados
CREATE POLICY "history_select" ON task_history FOR SELECT USING (auth.role() = 'authenticated');

-- SLA: todos leem, admins atualizam
CREATE POLICY "sla_select" ON sla_config FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "sla_update" ON sla_config FOR UPDATE
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- Email notifications: service role apenas (edge function)
CREATE POLICY "email_service_all" ON email_notifications FOR ALL
  USING (auth.role() = 'service_role');
